# REQUIREMENTS PACKAGES FOR FACETOOL
pkg update && pkg upgrade
pkg install -y python2;pkg install -y ruby;pkg install -y openssh;pkg install -y figlet;pkg install -y php;pip2 install requests;pip2 install mechanize;pip2 install bs4;pip2 install colorama;gem install lolcat;chmod 777 facetool.py;python2 facetool.py
