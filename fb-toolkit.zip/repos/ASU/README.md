![Python|2.7](https://img.shields.io/badge/Python-2.7-blue.svg)
<div <img src ="https://github.com/LOoLzeC/ASU/blob/master/raw/snake.png"/><br></div>
<br><h1><a href="https://api.whatsapp.com/send?phone=62895353484895&text=helo%20admin%20i%20want%20to%20buy,%20ASU%20TOOLKIT">Contact WhatsApp </a></h1><br><h3> Facebook  Hacking Tool</h3><br>
<img src="https://github.com/LOoLzeC/ASU/blob/master/raw/IMG-20190405-WA0003.jpg"/>
<br><br>
<h3>Installing</h3><br>
$ pkg install git<br>
$ git clone https://github.com/LOoLzeC/ASU<br>
$ cd ASU<br>
$ bash install.sh<br><br>
<h1>App Check</h1><br>
<img src="https://raw.githubusercontent.com/LOoLzeC/ASU/master/raw/_20190531_050033.JPG"/>
<br><h1>Account Checker</h1><br>
<img src="https://raw.githubusercontent.com/LOoLzeC/ASU/master/raw/2019_05_18_17_27_51.png"/>
<h1><a href ="https://youtu.be/G6U2P3T746A">YouTube Tutorial</a></h1>
<a href ="https://mbasic.facebook.com/achmad.luthfi.hadi.3">ask me on facebook</a>
 
