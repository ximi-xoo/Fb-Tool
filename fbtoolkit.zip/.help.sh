clear
echo -e "\e[1;31m"
figlet MENU
echo -e "\e[1;34m Created By \e[1;32m"
toilet -f mono12 -F border B.C.M
echo -e "\e[4;34m This TOOL Was Created By VIRUS 07 \e[0m"
echo -e "\e[1;34m For Any Queries Mail Me!!!\e[0m"
echo -e "\e[1;32m           Mail: ariyankhanoyon@gmail.com \e[0m"
echo -e "\e[4;32m        FB Page: https://www.facebook.com/c/darkbet.ariyan \e[0m"
echo " "
echo -e "\e[4;31m Please Read Instruction Carefully !!! \e[0m"
echo "----------------------------------- "
echo "| command             description | "
echo "|---------------------------------| "
echo "|1|   ======>    Show All Tools   | "
echo "|-|-------------------------------| "
echo "|2|   ======>    Install All Pkg  | "
echo "|-|-------------------------------| "
echo "|3|   ======>    ABOUT VIRUS 07   | "
echo "|-|-------------------------------| "
echo "|4|   ======>     EXIT            | "
echo "----------------------------------- "
read ch
if [ $ch -eq 1 ];then
clear
echo -e "\e[1;32m"
bash .show.sh
exit 0
elif [ $ch -eq 2 ];then
clear
echo -e "\e[1;32m"
echo 'Virus-07'
bash install.sh
exit 0
elif [ $ch -eq 3 ];then
clear
figlet VIRUS 07
echo "VIRUS 07 IS A PUBLIC HELPLINE OF BANGLADESH "
echo " THE C.E.O OF VIRUS 07 IS ARMAN KOWSER EMON "
echo " THE ADMIN OF VIRUS 07 IS MD: SHOJIB "
echo " THE SYSTEM CREATOR OF VIRUS 07 NILADRITA NILA "
echo " THE SYSTEM KILLER OF VIRUS 07 IS ARIYAN KHAN OYON "
toilet -f mono12 -F border NILA
toilet -f mono12 -F border ARIYAN
echo "Press Enter To Restart Programme "
read a1
bash .help.sh
exit 0
elif [ $ch -eq 4 ];then
figlet BYE
echo "Press Enter To Go MENU"
read a1
exit 0
elif [ $ch -eq 5 ];then
clear
bash install.sh
exit 0
bash darktool.sh
elif [ $ch -eq 6 ];then
clear
echo -e "\e[1;31m"
figlet FB TOOL
echo -e "\e[1;34m Created By \e[1;32m"
toilet -f mono12 -F border VIRUS
echo -e "\e[1;34m For Any Queries Mail Me!!!\e[0m"
echo -e "\e[1;32m           Mail: virus07hackingteam@gmail.com \e[0m"
echo -e "\e[1;32m       Facebook: https://m.facebook.com/virus.07.hacker \e[0m"
echo -e "\e[4;32m   Special Thanks To Nila \e[0m"
echo " "
exit 0
else
echo -e "\e[4;32m Invalid Input !!! \e[0m"
echo "Press Enter To Go Home"
read a3
clear
fi
done