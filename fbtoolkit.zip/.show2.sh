clear
echo
echo
echo -e "\e[1;31m"
figlet MENU
echo -e "\e[1;34m Created By \e[1;32m"
toilet -f mono12 -F border VIRUS
echo -e "\e[4;34m This TOOL Was Created By VIRUS 07 \e[0m"
echo -e "\e[1;34m For Any Queries Mail Me!!!\e[0m"
echo -e "\e[1;32m           Mail: ariyankhanoyon@gmail.com \e[0m"
echo -e "\e[4;32m        FB Page: https://www.facebook.com/c/darkbet.ariyan \e[0m"
echo " "
echo -e "\e[4;31m Please Read Instruction Carefully !!! \e[0m"
echo " "
echo "----------------------------------- "
echo "|          | Best Tool |           | "
echo "|----------------------------------| "
echo "|1. Darkfb version GOLD            | "
echo "|----------------------------------| "
echo "|2. Darkfb version KING            | "
echo "|----------------------------------| "
echo "|3. Multi Bruteforce               | "
echo "|----------------------------------| "
echo "|4. Target Bruteforce              | "
echo "|----------------------------------| "
echo "|5. Auto Grab ID                   | "
echo "-----------------------------------| "
echo "|6. Asu Toolkit  V5                | "
echo "-----------------------------------| "
echo "|7. OSIF Framework                 | "
echo "-----------------------------------| "
echo "8. Exit                            | "
echo "----------------------------------- "
read ch
if [ $ch -eq 1 ];then
clear
cd .repos
python2 vg.py
exit 0
elif [ $ch -eq 2 ];then
clear
cd .repos
python2 vk.py
exit 0
elif [ $ch -eq 3 ];then
clear
cd .repos
python2 mbf1.py
exit 0
elif [ $ch -eq 4 ];then
clear
cd .repos
python2 tbf.py
exit 0
elif [ $ch -eq 5 ];then
clear
cd .repos
python2 comz.py
exit 0
elif [ $ch -eq 6 ];then
clear
cd .repos
cd ASU
python2 ASU.py
exit 0
elif [ $ch -eq 7 ];then
clear
cd .repos
python2 osif.py
elif [ $ch -eq 8 ];then
clear
echo -e "\e[1;31m"
figlet FB TOOL
echo -e "\e[1;34m Created By \e[1;32m"
toilet -f mono12 -F border B.C.M
echo -e "\e[1;34m For Any Queries Mail Me!!!\e[0m"
echo -e "\e[1;32m           Mail: ariyankhanoyon@gmail.com \e[0m"
echo -e "\e[1;32m       Facebook: https://m.facebook.com/darkbet.ariyan \e[0m"
echo -e "\e[4;32m   Special Thanks To Nila \e[0m"
echo " "
exit 0
else
echo -e "\e[4;32m Invalid Input !!! \e[0m"
echo "Press Enter To Go Home"
read a3
clear
toilet -f mono12 -F border NILA
toilet -f mono12 -F border ARIYAN
fi
done