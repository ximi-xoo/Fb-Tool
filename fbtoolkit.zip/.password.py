from getpass import getpass
import os
import time

def menu():
      while True:
           print("")
           os.system("clear")
           print('\033[1;36;40m<───────────────( B.C.M )───────────────>')
           print('')
           os.system('date | lolcat')
           print("\033[1;93m")
           print(" \033[1;92m  786 => bismi-llāhir-raḥmānir-raḥīm')")
           print("\033[1;93m")
           print("  <───────[ Assalamu-Alaikum ]───────>")
           print("")
           try:
                x = str(input('\033[1;92mUsername \033[1;93m: '))
                print("")
                e = getpass('\033[1;92mPassword \033[1;93m: ')
                print ("")
                if x=="Ariyan" and e=="nilur_xan_oyon":
                   print('wait...')
                   time.sleep(1)
                   os.system('clear')
                   print('')
                   print('\033[1;92m ─────────────────────────────────── ')
                   print('\033[1;92m |BANGLADESH CYBER MAFIA ( B.C.M ) | ')
                   print('\033[1;92m ─────────────────────────────────── ')
                   print(" Press Enter For Continue ")
                   os.system('read a1')
                   os.system('clear')
                   break
                else:
                      print("")
                      print("")
                      print("")
                      print("")
                      print("\033[1;91m     Wrong Password")
                      time.sleep(2)
                      print("")
           except Exception:
                      
                      print("")
                      print("")
                      print("")
                      print("")
                      print("")
                      print("\033[1;91m     Wrong Password")
                      time.sleep(2)
           except KeyboardInterrupt:
                      print("")
                      os.system('killall -9 com.termux')
                      print("")
                      print("")
                      print("")
                      print("")
                      print("\033[1;91m     Wrong Password")
                      time.sleep(2)
menu()


